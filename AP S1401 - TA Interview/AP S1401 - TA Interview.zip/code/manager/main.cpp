#include "../cli/cli.hpp"

using namespace std;

int main(int argc, char *argv[]) {
    CLI cli;
    cli.run();
    return 0;
}